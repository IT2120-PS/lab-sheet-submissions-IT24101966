setwd("D:\\Lab 06")

# Question 1
#What is the distribution of X?
#random variable x has binominal distribution with n=50, p=0.85

#What is the probability that at least 47 students passed the test?
prob_at_least_47 <- pbinom(46, 50, 0.85)
print(prob_at_least_47)


#Question 2
#What is the random variable (X) for the problem?
#X is the number of customer calls recived in one hour

#What is the distribution of X?
#Random variable X has a Poisson Distribution (lambda=12)

#What is the probability that exactly 15 calls are received in an hour?
prob_exactly_15 <- dpois(15, 12)
print(prob_exactly_15)