#set working directory
setwd("C:\\Users\\it24101966\\Desktop\\IT24101966")

#import data set
data <- read.table("Data - Lab 8.txt", header = TRUE)

fix(data)  #look data 
attach(data)  #now directly use column names

#Q1
#1. Calculate population mean and variance of the data set
popmn <- mean(Nicotine)
popvar <- var(Nicotine)

#2. Get 30 random samples of size 5, 
#with replacement and calculate sample mean and sample variance for each sample.

samples <- c()
n <- c()

for(i in 1:30){
  s <- sample(Nicotine,5,replace = TRUE)
  samples <- cbind(samples,s)
  n <- c(n,paste('s',i))
}
colnames(samples) = n

s.means <- apply(samples, 2, mean) 
s.vars <- apply(samples, 2, var)

#3. Calculate mean and variance of the Sample Means.
samplemean <- mean(s.means)
samplevars <- var(s.means)

#4. Compare and state relationship (if any) Population Mean and the Mean of Sample Means.
popmn
samplemean

#5. Compare and state relationship (if any) Population Variance and the Variance of Sample Means.
truevar = popvar / 5
samplevars

