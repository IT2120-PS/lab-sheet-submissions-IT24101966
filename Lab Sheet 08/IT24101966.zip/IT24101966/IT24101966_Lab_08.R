#set working directory
setwd("C:\\Users\\it24101966\\Desktop\\IT24101966")

#import data set
data <- read.table("Exercise - LaptopsWeights.txt", header = TRUE)

fix(data)  #look data 
attach(data)  #now directly use column names

#1.Calculate population mean and population standard deviation of the bag weights.
popmn <- mean(Weight.kg.)
popsd <- sd(Weight.kg.) 

#2.Draw 25 random samples of size 6 (with replacement) and 
#calculate the sample mean and sample standard deviation for each sample.
samples <- c()
n <- c()

for(i in 1:25){
  s <- sample(Weight.kg.,6,replace = TRUE)
  samples <- cbind(samples,s)
  n <- c(n,paste('s',i))
}
colnames(samples) = n

s.means <- apply(samples, 2, mean) 
s.diviation <- apply(samples, 2, sd)

#3.Calculate the mean and standard deviation of the 25 sample means and state the relationship of them with true mean and true standard deviation.

samplemean <- mean(s.means)  # Mean of sample means
sdeviation <- sd(s.means)    # Standard deviation of sample means

# Standard error of the sample means
standard_error <- popsd / sqrt(6)